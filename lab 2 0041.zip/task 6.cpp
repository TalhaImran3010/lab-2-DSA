#include <iostream>
#include <string>
#include <vector>
using namespace std;

template <typename T>
void selectionSort(T arr[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        int smallSub = i;

        for (int j = i + 1; j < size; j++)
        {
            if (arr[j] < arr[smallSub])
            {
                smallSub = j;
            }
        }

        T temp = arr[i];
        arr[i] = arr[smallSub];
        arr[smallSub] = temp;
    }
}

template <typename T>
int linearSearch(T arr[], int size, T value)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == value)
        {
            return i;
        }
    }

    return -1;
}

class LibraryItem
{
public:
    virtual void display() = 0;
    virtual ~LibraryItem() {}
};

class Book : public LibraryItem
{
private:
    string title;
    string author;
    int pages;

public:
    Book(string t, string a, int p)
    {
        title = t;
        author = a;
        pages = p;
    }

    string getTitle()
    {
        return title;
    }

    int getPages()
    {
        return pages;
    }

    void display() override
    {
        cout << "Book: " << title << endl;
        cout << "Author: " << author << endl;
        cout << "Pages: " << pages << endl;
    }

    bool operator<(const Book& other) const
    {
        return pages < other.pages;
    }

    bool operator==(const Book& other) const
    {
        return title == other.title;
    }
};

class Newspaper : public LibraryItem
{
private:
    string name;
    string date;
    string edition;

public:
    Newspaper(string n, string d, string e)
    {
        name = n;
        date = d;
        edition = e;
    }

    string getName()
    {
        return name;
    }

    string getEdition()
    {
        return edition;
    }

    void display() override
    {
        cout << "Newspaper: " << name << endl;
        cout << "Date: " << date << endl;
        cout << "Edition: " << edition << endl;
    }

    bool operator<(const Newspaper& other) const
    {
        return edition < other.edition;
    }

    bool operator==(const Newspaper& other) const
    {
        return name == other.name;
    }
};

class Library
{
private:
    vector<Book> books;
    vector<Newspaper> newspapers;

public:
    void addBook(Book book)
    {
        books.push_back(book);
    }

    void addNewspaper(Newspaper newspaper)
    {
        newspapers.push_back(newspaper);
    }

    void displayCollection()
    {
        cout << "\nBooks:\n";

        for (int i = 0; i < books.size(); i++)
        {
            books[i].display();
            cout << endl;
        }

        cout << "Newspapers:\n";

        for (int i = 0; i < newspapers.size(); i++)
        {
            newspapers[i].display();
            cout << endl;
        }
    }

    void sortBooksByPages()
    {
        if (!books.empty())
        {
            selectionSort(&books[0], books.size());
        }
    }

    void sortNewspapersByEdition()
    {
        if (!newspapers.empty())
        {
            selectionSort(&newspapers[0], newspapers.size());
        }
    }

    Book* searchBookByTitle(string title)
    {
        if (books.empty())
        {
            return nullptr;
        }

        Book key(title, "", 0);

        int index = linearSearch(&books[0], books.size(), key);

        if (index != -1)
        {
            return &books[index];
        }

        return nullptr;
    }

    Newspaper* searchNewspaperByName(string name)
    {
        if (newspapers.empty())
        {
            return nullptr;
        }

        Newspaper key(name, "", "");

        int index = linearSearch(&newspapers[0], newspapers.size(), key);

        if (index != -1)
        {
            return &newspapers[index];
        }

        return nullptr;
    }
};

int main()
{
    Book book1("The Catcher in the Rye", "J.D. Salinger", 277);
    Book book2("To Kill a Mockingbird", "Harper Lee", 324);

    Newspaper newspaper1("Washington Post", "2024-10-13", "Morning Edition");
    Newspaper newspaper2("The Times", "2024-10-12", "Weekend Edition");

    Library library;

    library.addBook(book1);
    library.addBook(book2);
    library.addNewspaper(newspaper1);
    library.addNewspaper(newspaper2);

    cout << "Before Sorting:\n";
    library.displayCollection();

    library.sortBooksByPages();
    library.sortNewspapersByEdition();

    cout << "\nAfter Sorting:\n";
    library.displayCollection();

    Book* foundBook = library.searchBookByTitle("The Catcher in the Rye");

    if (foundBook)
    {
        cout << "\nFound Book:\n";
        foundBook->display();
    }
    else
    {
        cout << "\nBook not found.\n";
    }

    Newspaper* foundNewspaper = library.searchNewspaperByName("The Times");

    if (foundNewspaper)
    {
        cout << "\nFound Newspaper:\n";
        foundNewspaper->display();
    }
    else
    {
        cout << "\nNewspaper not found.\n";
    }

    return 0;
}
