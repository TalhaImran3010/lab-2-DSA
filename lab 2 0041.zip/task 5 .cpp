#include <iostream>
#include <string>
using namespace std;


class Employee
{
public:
   
    virtual double calculateSalary() = 0;
};


class FullTimeEmployee : public Employee
{
private:
    string name;
    double fixedSalary;

public:
   
    FullTimeEmployee(string n, double salary)
    {
        name = n;
        fixedSalary = salary;
    }

  
    double calculateSalary() override
    {
        return fixedSalary;
    }

    string getName()
    {
        return name;
    }
};


class PartTimeEmployee : public Employee
{
private:
    string name;
    double hoursWorked;
    double hourlyRate;

public:
   
    PartTimeEmployee(string n, double hours, double rate)
    {
        name = n;
        hoursWorked = hours;
        hourlyRate = rate;
    }

    
    double calculateSalary() override
    {
        return hoursWorked * hourlyRate;
    }

    string getName()
    {
        return name;
    }
};

int main()
{
  
    FullTimeEmployee fullTime("Ali", 80000);

   
    PartTimeEmployee partTime("Ahmed", 40, 500);

  
    cout << "Full-Time Employee: " << fullTime.getName() << endl;
    cout << "Salary: " << fullTime.calculateSalary() << endl;

    cout << endl;

    cout << "Part-Time Employee: " << partTime.getName() << endl;
    cout << "Salary: " << partTime.calculateSalary() << endl;

    return 0;
}
